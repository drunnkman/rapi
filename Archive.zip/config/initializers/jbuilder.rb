Jbuilder.key_format camelize: :lower
